package com.lusa.applighttheme

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AppDetailActivity : AppCompatActivity() {
    
    private lateinit var appIconImageView: ImageView
    private lateinit var appNameTextView: TextView
    private lateinit var packageNameTextView: TextView
    private lateinit var versionTextView: TextView
    private lateinit var categoryTextView: TextView
    private lateinit var launchButton: Button
    private lateinit var shareButton: Button
    private lateinit var uninstallButton: Button
    
    private var packageName: String = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_detail)
        
        packageName = intent.getStringExtra("package_name") ?: ""
        if (packageName.isEmpty()) {
            finish()
            return
        }
        
        setupViews()
        setupFonts()
        loadAppInfo()
        setupListeners()
    }
    
    private fun setupViews() {
        appIconImageView = findViewById(R.id.appIconImageView)
        appNameTextView = findViewById(R.id.appNameTextView)
        packageNameTextView = findViewById(R.id.packageNameTextView)
        versionTextView = findViewById(R.id.versionTextView)
        categoryTextView = findViewById(R.id.categoryTextView)
        launchButton = findViewById(R.id.launchButton)
        shareButton = findViewById(R.id.shareButton)
        uninstallButton = findViewById(R.id.uninstallButton)
    }
    
    private fun setupFonts() {
        try {
            val kanitBold = Typeface.createFromAsset(assets, "fonts/Kanit-Bold.ttf")
            val kanitRegular = Typeface.createFromAsset(assets, "fonts/Kanit-Regular.ttf")
            
            appNameTextView.typeface = kanitBold
            launchButton.typeface = kanitBold
            shareButton.typeface = kanitBold
            uninstallButton.typeface = kanitBold
            packageNameTextView.typeface = kanitRegular
            versionTextView.typeface = kanitRegular
            categoryTextView.typeface = kanitRegular
        } catch (e: Exception) {
            appNameTextView.typeface = Typeface.DEFAULT_BOLD
            launchButton.typeface = Typeface.DEFAULT_BOLD
            shareButton.typeface = Typeface.DEFAULT_BOLD
            uninstallButton.typeface = Typeface.DEFAULT_BOLD
            packageNameTextView.typeface = Typeface.DEFAULT
            versionTextView.typeface = Typeface.DEFAULT
            categoryTextView.typeface = Typeface.DEFAULT
        }
    }
    
    private fun loadAppInfo() {
        try {
            val packageManager = packageManager
            val applicationInfo = packageManager.getApplicationInfo(packageName, 0)
            
            appIconImageView.setImageDrawable(applicationInfo.loadIcon(packageManager))
            appNameTextView.text = applicationInfo.loadLabel(packageManager).toString()
            packageNameTextView.text = packageName
            
            // Get version info
            val packageInfo = packageManager.getPackageInfo(packageName, 0)
            versionTextView.text = getString(R.string.version_label, packageInfo.versionName)
            
            // Get category
            val category = getAppCategory(packageName)
            categoryTextView.text = getString(R.string.category_label, category)
            
        } catch (e: PackageManager.NameNotFoundException) {
            Toast.makeText(this, getString(R.string.app_not_found), Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun getAppCategory(packageName: String): String {
        return when {
            packageName.startsWith("com.whatsapp") -> "Mạng xã hội"
            packageName.startsWith("com.facebook") -> "Mạng xã hội"
            packageName.startsWith("com.instagram") -> "Mạng xã hội"
            packageName.startsWith("org.telegram") -> "Mạng xã hội"
            packageName.startsWith("com.twitter") -> "Mạng xã hội"
            packageName.startsWith("com.google.android.youtube") -> "Giải trí"
            packageName.startsWith("com.netflix") -> "Giải trí"
            packageName.startsWith("com.spotify") -> "Giải trí"
            packageName.startsWith("com.google.android.gm") -> "Liên lạc"
            packageName.startsWith("com.android.chrome") -> "Trình duyệt"
            packageName.startsWith("com.google.android.camera") -> "Camera"
            packageName.startsWith("com.google.android.music") -> "Âm nhạc"
            packageName.startsWith("com.google.android.apps.maps") -> "Điều hướng"
            else -> "Khác"
        }
    }
    
    private fun setupListeners() {
        launchButton.setOnClickListener {
            launchApp()
        }
        
        shareButton.setOnClickListener {
            shareApp()
        }
        
        uninstallButton.setOnClickListener {
            uninstallApp()
        }
    }
    
    private fun launchApp() {
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.cannot_launch_app), Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun shareApp() {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Ứng dụng: ${appNameTextView.text}\nPackage: $packageName")
            }
            startActivity(Intent.createChooser(intent, getString(R.string.share_app_title)))
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.cannot_share_app), Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun uninstallApp() {
        try {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.cannot_uninstall_app), Toast.LENGTH_SHORT).show()
        }
    }
} 