package com.lusa.applighttheme

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class AppListActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var searchEditText: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var appsAdapter: AppsAdapter
    private var allApps = mutableListOf<AppInfo>()
    private var filteredApps = mutableListOf<AppInfo>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_list)
        
        setupViews()
        setupFonts()
        loadApps()
        setupSearch()
        setupCategoryFilter()
    }
    
    private fun setupViews() {
        recyclerView = findViewById(R.id.recyclerView)
        searchEditText = findViewById(R.id.searchEditText)
        categorySpinner = findViewById(R.id.categorySpinner)
        
        recyclerView.layoutManager = GridLayoutManager(this, 4)
        appsAdapter = AppsAdapter(filteredApps,
            onAppClick = {appInfo ->
                launchApp(appInfo)
            },
            onAppLongClick = { appInfo ->
                openAppDetail(appInfo)
            })
        recyclerView.adapter = appsAdapter
    }
    
    private fun setupFonts() {
        try {
            val kanitRegular = Typeface.createFromAsset(assets, "fonts/Kanit-Regular.ttf")
            searchEditText.typeface = kanitRegular
        } catch (e: Exception) {
            searchEditText.typeface = Typeface.DEFAULT
        }
    }
    
    private fun loadApps() {
        val packageManager = packageManager
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        
        allApps.clear()
        
        for (app in installedApps) {
            if (packageManager.getLaunchIntentForPackage(app.packageName) != null) {
                val appInfo = AppInfo(
                    name = app.loadLabel(packageManager).toString(),
                    packageName = app.packageName,
                    icon = app.loadIcon(packageManager),
                    category = getAppCategory(app.packageName)
                )
                allApps.add(appInfo)
            }
        }
        
        // Sort apps alphabetically
        allApps.sortBy { it.name.lowercase() }
        filteredApps.addAll(allApps)
        appsAdapter.notifyDataSetChanged()
    }
    
    private fun getAppCategory(packageName: String): String {
        return when {
            packageName.startsWith("com.whatsapp") -> "Social"
            packageName.startsWith("com.facebook") -> "Social"
            packageName.startsWith("com.instagram") -> "Social"
            packageName.startsWith("org.telegram") -> "Social"
            packageName.startsWith("com.twitter") -> "Social"
            packageName.startsWith("com.google.android.youtube") -> "Entertainment"
            packageName.startsWith("com.netflix") -> "Entertainment"
            packageName.startsWith("com.spotify") -> "Entertainment"
            packageName.startsWith("com.google.android.gm") -> "Communication"
            packageName.startsWith("com.android.chrome") -> "Browser"
            packageName.startsWith("com.google.android.camera") -> "Camera"
            packageName.startsWith("com.google.android.music") -> "Music"
            packageName.startsWith("com.google.android.apps.maps") -> "Navigation"
            else -> "Other"
        }
    }
    
    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterApps()
            }
        })
    }
    
    private fun setupCategoryFilter() {
        val categories = listOf(
            getString(R.string.category_all),
            getString(R.string.category_social),
            getString(R.string.category_entertainment),
            getString(R.string.category_communication),
            getString(R.string.category_browser),
            getString(R.string.category_camera),
            getString(R.string.category_music),
            getString(R.string.category_navigation),
            getString(R.string.category_other)
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter
        
        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                filterApps()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }
    
    private fun filterApps() {
        val searchQuery = searchEditText.text.toString().lowercase()
        val selectedCategory = categorySpinner.selectedItem.toString()
        
        filteredApps.clear()
        
        for (app in allApps) {
            val matchesSearch = app.name.lowercase().contains(searchQuery)
            val matchesCategory = selectedCategory == getString(R.string.category_all) || 
                                 getCategoryString(app.category) == selectedCategory
            
            if (matchesSearch && matchesCategory) {
                filteredApps.add(app)
            }
        }
        
        appsAdapter.notifyDataSetChanged()
    }
    
    private fun getCategoryString(category: String): String {
        return when (category) {
            "Social" -> getString(R.string.category_social)
            "Entertainment" -> getString(R.string.category_entertainment)
            "Communication" -> getString(R.string.category_communication)
            "Browser" -> getString(R.string.category_browser)
            "Camera" -> getString(R.string.category_camera)
            "Music" -> getString(R.string.category_music)
            "Navigation" -> getString(R.string.category_navigation)
            else -> getString(R.string.category_other)
        }
    }
    
    private fun launchApp(appInfo: AppInfo) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(appInfo.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.cannot_launch_app), Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun openAppDetail(appInfo: AppInfo) {
        val intent = Intent(this, AppDetailActivity::class.java).apply {
            putExtra("package_name", appInfo.packageName)
        }
        startActivity(intent)
    }
    
    data class AppInfo(
        val name: String,
        val packageName: String,
        val icon: android.graphics.drawable.Drawable,
        val category: String
    )
    
    inner class AppsAdapter(
        private val apps: List<AppInfo>,
        private val onAppClick: (AppInfo) -> Unit,
        private val onAppLongClick: (AppInfo) -> Unit
    ) : RecyclerView.Adapter<AppsAdapter.AppViewHolder>() {
        
        inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val iconImageView: ImageView = itemView.findViewById(R.id.appIcon)
            private val nameTextView: TextView = itemView.findViewById(R.id.appName)
            
            fun bind(appInfo: AppInfo) {
                iconImageView.setImageDrawable(appInfo.icon)
                nameTextView.text = appInfo.name
                
                itemView.setOnClickListener {
                    onAppClick(appInfo)
                }
                
                itemView.setOnLongClickListener {
                    onAppLongClick(appInfo)
                    true
                }
            }
        }
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_app, parent, false)
            return AppViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
            holder.bind(apps[position])
        }
        
        override fun getItemCount(): Int = apps.size
    }
} 