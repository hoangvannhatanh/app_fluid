package com.lusa.applighttheme

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LauncherMainActivity : AppCompatActivity() {
    
    private lateinit var openAppLauncherButton: Button
    private lateinit var createShortcutsButton: Button
    private lateinit var titleText: TextView
    private lateinit var descriptionText: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher_main)
        
        setupViews()
        setupFonts()
        setupListeners()
    }
    
    private fun setupViews() {
        openAppLauncherButton = findViewById(R.id.openAppLauncherButton)
        createShortcutsButton = findViewById(R.id.createShortcutsButton)
        titleText = findViewById(R.id.titleText)
        descriptionText = findViewById(R.id.descriptionText)
    }
    
    private fun setupFonts() {
        try {
            val kanitBold = Typeface.createFromAsset(assets, "fonts/Kanit-Bold.ttf")
            val kanitRegular = Typeface.createFromAsset(assets, "fonts/Kanit-Regular.ttf")
            
            titleText.typeface = kanitBold
            openAppLauncherButton.typeface = kanitBold
            createShortcutsButton.typeface = kanitBold
            descriptionText.typeface = kanitRegular
        } catch (e: Exception) {
            titleText.typeface = Typeface.DEFAULT_BOLD
            openAppLauncherButton.typeface = Typeface.DEFAULT_BOLD
            createShortcutsButton.typeface = Typeface.DEFAULT_BOLD
            descriptionText.typeface = Typeface.DEFAULT
        }
    }
    
    private fun setupListeners() {
        openAppLauncherButton.setOnClickListener {
            val intent = Intent(this, AppListActivity::class.java)
            startActivity(intent)
        }
        
        createShortcutsButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
} 